document.addEventListener('DOMContentLoaded', () => {
    const prevButton = document.querySelector('.carousel-prev');
    const nextButton = document.querySelector('.carousel-next');
    const carouselInner = document.querySelector('.carousel-inner');
    const items = document.querySelectorAll('.carousel-item');
    
    let currentIndex = 0;

    function showItem(index) {
        if (index >= items.length) {
            currentIndex = 0;
        } else if (index < 0) {
            currentIndex = items.length - 1;
        } else {
            currentIndex = index;
        }
    
        // Log the current index to see which image is being displayed
        console.log("Current index:", currentIndex);
    
        // Move the carousel by setting the transform property
        carouselInner.style.transform = `translateX(-${currentIndex * 100}%)`;
    }
    

    prevButton.addEventListener('click', () => {
        showItem(currentIndex - 1);
    });

    nextButton.addEventListener('click', () => {
        showItem(currentIndex + 1);
    });
});
