const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define the blog schema
const blogSchema = new Schema({
    title: {
        type: String,
        required: true
    },
    snippet: {
        type: String,
        required: true
    },
    body: {
        type: String,
        required: true
    }
}, { timestamps: true }); // Automatically adds createdAt and updatedAt fields

// Create the Blog model
const Blog = mongoose.model('Blog', blogSchema);

// Export the Blog model
module.exports = Blog;
