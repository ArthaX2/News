const express = require('express');
const mongoose = require('mongoose');
const handlebars = require('express-handlebars');
const Blog = require('./models/blog'); // Importing the Blog model

const app = express();

// Connect to MongoDB
const dbURl = 'mongodb+srv://Artha:04062008@cluster0.2wap5.mongodb.net/atlasAdmin@admin?retryWrites=true&w=majority&appName=Cluster0';
mongoose.connect(dbURl)
    .then(() => {
        console.log('connected to db');
        const PORT = 3000;
        app.listen(PORT, () => {
            console.log(`Server is running on http://127.0.0.1:${PORT}`);
        });
    })
    .catch(err => console.log(err));

// Set Handlebars as the view engine
app.engine('handlebars', handlebars.engine());
app.set('view engine', 'handlebars');

// Middleware to serve static files
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

// Routes

// Home page - List all blogs
app.get('/', (req, res) => {
    Blog.find().sort({ createdAt: -1 })
        .then(result => {
            res.render('index', {
                title: 'Home Page',
                blogs: result,
                message: 'Welcome to Mario Kart!'
            });
        })
        .catch(err => {
            console.log(err);
        });
});

// About page
app.get('/about', (req, res) => {
    res.render('about', { title: 'About Mario Kart' });
});

// Mario Kart Characters page
app.get('/characters', (req, res) => {
    res.render('characters', { title: 'Mario Kart Characters' });
});

// Map page
app.get('/map', (req, res) => {
    res.render('map', { title: 'Mario Kart Map' });
});

// Create a new blog page
app.get('/blogs/create', (req, res) => {
    res.render('create', { title: 'Create a new blog' });
});

// Adding a blog to MongoDB
app.post('/blogs', (req, res) => {
    const blog = new Blog(req.body);

    blog.save()
        .then(() => {
            res.redirect('/');
        })
        .catch(err => {
            console.log(err);
        });
});

// View all blogs
app.get('/blogs', (req, res) => {
    Blog.find().sort({ createdAt: -1 })
        .then(result => {
            res.render('blogs', { title: 'All Blogs', blogs: result });
        })
        .catch(err => {
            console.log(err);
        });
});

// Example route for adding a blog programmatically (sandbox)
app.get('/add.blog', (req, res) => {
    const blog = new Blog({
        title: 'new blog 1',
        snippet: 'about my new blog',
        body: 'more about my new blog'
    });

    blog.save()
        .then(result => {
            res.send(result);
        })
        .catch(err => {
            console.log(err);
        });
});

// 404 page
app.use((req, res) => {
    res.status(404).render('404', { title: '404 Page Not Found' });
});
